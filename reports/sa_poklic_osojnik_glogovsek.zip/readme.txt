Oddano:
- SA_koncno_porocilo.pdf: tehnicna dokumentacija, pregled alternativ uporabljenim tehnologijam,...
- povezava (github): 


https://github.com/domen-osojnik/final_project

