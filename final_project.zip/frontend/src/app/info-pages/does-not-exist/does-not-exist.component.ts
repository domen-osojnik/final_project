import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-does-not-exist',
  templateUrl: './does-not-exist.component.html',
  styleUrls: ['./does-not-exist.component.css']
})
export class DoesNotExistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
