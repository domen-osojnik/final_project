import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-tracker',
  templateUrl: './sign-tracker.component.html',
  styleUrls: ['./sign-tracker.component.css']
})
export class SignTrackerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
